create table #dblib0016 (f1 int not null, str nvarchar(5), uuid uniqueidentifier)
go
select * from #dblib0016 where 0=1
go
select * from #dblib0016 where 0=1
go
drop table #dblib0016
go

