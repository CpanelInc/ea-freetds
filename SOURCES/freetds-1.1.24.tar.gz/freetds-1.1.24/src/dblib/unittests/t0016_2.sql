create table #dblib0016 (f1 int not null, f2 text, f3 varchar(20) )
go
select * from #dblib0016 where 0=1
go
select * from #dblib0016 where 0=1
go
drop table #dblib0016
go

