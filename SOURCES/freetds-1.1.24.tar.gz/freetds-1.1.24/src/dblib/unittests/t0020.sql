/* request an invalid column from a non-existent table */
select dsjfkl dsjf
go
select db_name()
go
