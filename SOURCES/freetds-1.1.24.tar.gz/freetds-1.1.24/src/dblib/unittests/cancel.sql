select * from I_dont_exists_table
go
select 1 as one
go
